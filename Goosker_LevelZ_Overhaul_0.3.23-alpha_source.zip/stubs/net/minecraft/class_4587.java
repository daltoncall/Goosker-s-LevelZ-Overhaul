package net.minecraft;
public class class_4587 {
    public void method_22903() {}
    public void method_22909() {}
    public void method_22904(double x, double y, double z) {}
    public void method_22905(float x, float y, float z) {}
}
