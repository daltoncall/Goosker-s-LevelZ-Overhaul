package net.levelz.stats;
public class PlayerStatsManager {
    public int getSkillLevel(Skill s){ return 0; }
    public int getOverallLevel(){ return 0; }
    public int getSkillPoints(){ return 0; }
    public int getNextLevelExperience(){ return 1; }
    public float getLevelProgress(){ return 0f; }
}
