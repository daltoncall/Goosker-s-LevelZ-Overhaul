package org.spongepowered.asm.mixin;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target({ElementType.FIELD,ElementType.METHOD})
public @interface Shadow { String prefix() default "shadow$"; boolean remap() default true; }
