package net.minecraft; public class class_6862<T> {}
