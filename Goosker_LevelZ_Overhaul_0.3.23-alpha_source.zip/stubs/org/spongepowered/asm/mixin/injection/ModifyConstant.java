package org.spongepowered.asm.mixin.injection;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD)
public @interface ModifyConstant { String[] method(); Constant[] constant(); int require() default -1; boolean remap() default true; }
