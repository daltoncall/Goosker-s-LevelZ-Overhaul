package net.minecraft;
public class class_1109 implements class_1113 {
    public static class_1109 method_4757(class_3414 event, float pitch, float volume) { return null; }
    public static class_1109 method_47978(class_6880<class_3414> event, float pitch) { return null; }
}
