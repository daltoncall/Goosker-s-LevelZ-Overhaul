package net.minecraft;
public interface class_2561 {
    static class_5250 method_43471(String key) { return null; }
    static class_2561 method_30163(String text) { return null; }
}
