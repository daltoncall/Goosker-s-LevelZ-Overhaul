package org.spongepowered.asm.mixin.injection;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target({})
public @interface Constant { int intValue() default 0; int ordinal() default -1; }
