package net.minecraft;
public class class_437 {
    protected int field_22789;
    protected int field_22790;
}
