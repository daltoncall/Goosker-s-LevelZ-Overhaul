package net.minecraft;
public class class_332 {
    public class_4587 method_51448() { return new class_4587(); }
    public void method_25302(class_2960 texture, int x, int y, int u, int v, int w, int h) {}
    public void method_25290(class_2960 texture, int x, int y, float u, float v, int w, int h, int texW, int texH) {}
    public int method_51439(class_327 renderer, class_2561 text, int x, int y, int color, boolean shadow) { return 0; }
    public int method_51433(class_327 renderer, String text, int x, int y, int color, boolean shadow) { return 0; }
}
