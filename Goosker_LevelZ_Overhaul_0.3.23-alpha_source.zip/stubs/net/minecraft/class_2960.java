package net.minecraft;
public class class_2960 { public class_2960(String id) {} }
