package net.levelz.stats;
public enum Skill {
    HEALTH, DEFENSE, AGILITY, STRENGTH, ALCHEMY, ARCHERY, TRADE, SMITHING, MINING, FARMING;
}
