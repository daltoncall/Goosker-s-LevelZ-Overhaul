package net.minecraft;
public class class_3414 {
    public static class_3414 method_47908(class_2960 id) { return null; }
}
