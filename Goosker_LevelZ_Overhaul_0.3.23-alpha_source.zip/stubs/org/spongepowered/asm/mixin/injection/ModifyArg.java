package org.spongepowered.asm.mixin.injection;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD)
public @interface ModifyArg { String[] method(); At at(); int index() default -1; int require() default -1; boolean remap() default true; }
