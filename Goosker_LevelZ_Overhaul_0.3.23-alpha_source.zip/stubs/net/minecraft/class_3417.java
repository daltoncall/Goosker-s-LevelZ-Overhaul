package net.minecraft;
public class class_3417 {
    public static final class_6880<class_3414> field_15015 = null;
}
