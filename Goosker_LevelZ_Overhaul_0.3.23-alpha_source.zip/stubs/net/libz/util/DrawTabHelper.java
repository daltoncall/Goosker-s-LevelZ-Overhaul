package net.libz.util;
import net.minecraft.class_310; import net.minecraft.class_332; import net.minecraft.class_437;
public final class DrawTabHelper {
    public static void drawTab(class_310 client, class_332 ctx, class_437 screen, int x, int y, int mouseX, int mouseY) {}
}
