package org.spongepowered.asm.mixin.injection.callback;
public class CallbackInfoReturnable<T> extends CallbackInfo { public T getReturnValue(){return null;} public void setReturnValue(T v){} }
