package net.minecraft;
public class class_1144 {
    public void method_4873(class_1113 sound) {}
}
