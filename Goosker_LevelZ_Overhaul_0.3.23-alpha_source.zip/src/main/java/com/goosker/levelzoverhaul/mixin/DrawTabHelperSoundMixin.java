package com.goosker.levelzoverhaul.mixin;

import com.goosker.levelzoverhaul.CompatUtil;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds a single UI click exactly when LibZ commits a tab switch. */
@Mixin(targets = "net.libz.util.DrawTabHelper", remap = false)
public abstract class DrawTabHelperSoundMixin {
    @Inject(
        method = "onTabButtonClick",
        at = @At(
            value = "INVOKE",
            target = "Lnet/libz/api/InventoryTab;onClick(Lnet/minecraft/class_310;)V",
            shift = At.Shift.BEFORE,
            remap = false
        ),
        require = 1,
        remap = false
    )
    private static void goosker$playTabSwitchClick(class_310 client, class_437 screenClass,
                                                    int x, int y, double mouseX, double mouseY,
                                                    boolean focused, CallbackInfo ci) {
        CompatUtil.playMenuClick();
    }
}
