package com.goosker.levelzoverhaul;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;

/** Optional compatibility helpers for Flow and Satisfying Buttons. */
public final class CompatUtil {
    private CompatUtil() {}

    /** Suppress Flow's next transition without disabling Flow globally. */
    public static void suppressNextFlowEaseIn() {
        try {
            Class<?> api = Class.forName("dev.imb11.flow.api.FlowAPI");
            Field disabled = api.getField("DISABLE_TEMPORARILY");
            if (!disabled.getBoolean(null)) {
                api.getMethod("toggleTemporaryDisable").invoke(null);
            }
        } catch (Throwable ignored) {
        }
    }

    /** Uses Satisfying Buttons' own sound events/config when that mod is present. */
    public static void satisfyingHoverChanged(boolean hovered, boolean wasHovered) {
        if (hovered == wasHovered) return;
        try {
            Class.forName("toni.satisfyingbuttons.SatisfyingButtonsClient");
            SatisfyingButtonsBridge.playHover(hovered);
        } catch (Throwable ignored) {
        }
    }

    /**
     * Vanilla ui.button.click by registry id.
     *
     * Do not depend on a mapped SoundEvents field here: this addon is compiled
     * against intermediary names, and the earlier field-based attempt resolved to
     * the wrong event in this 1.20.1 environment. Creating the SoundEvent from the
     * stable registry id keeps the Inventory <-> LevelZ and back-arrow click audible.
     */
    public static void playMenuClick() {
        try {
            class_3414 event = class_3414.method_47908(new class_2960("minecraft:ui.button.click"));
            class_310.method_1551().method_1483().method_4873(
                class_1109.method_4757(event, 1.0F, 0.25F)
            );
        } catch (Throwable ignored) {
        }
    }

    /** Reads AbstractWidget's hovered state from a LevelZ custom button. */
    public static boolean isHovered(Object widget) {
        try {
            Method method = widget.getClass().getMethod("method_49606");
            return Boolean.TRUE.equals(method.invoke(widget));
        } catch (Throwable ignored) {
            // Fallback to the inherited hover flag if mappings/method lookup changes.
            try {
                Field field = findField(widget.getClass(), "field_22766");
                if (field != null) {
                    field.setAccessible(true);
                    return field.getBoolean(widget);
                }
            } catch (Throwable ignoredToo) {
            }
            return false;
        }
    }

    /** Reads the inherited active flag; defaults true if mappings change. */
    public static boolean isActive(Object widget) {
        try {
            Field field = findField(widget.getClass(), "field_22763");
            if (field == null) return true;
            field.setAccessible(true);
            return field.getBoolean(widget);
        } catch (Throwable ignored) {
            return true;
        }
    }

    private static Field findField(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }
}
