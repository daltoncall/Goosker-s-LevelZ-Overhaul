package net.minecraft; public interface class_5819 { float method_43057(); }
