package net.minecraft; public class class_1799 { public boolean method_31573(class_6862<?> tag){return false;} public class_1799 method_46651(int count){return this;} }
