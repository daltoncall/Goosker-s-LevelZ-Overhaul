package net.minecraft;
public class class_746 extends class_1657 {}
