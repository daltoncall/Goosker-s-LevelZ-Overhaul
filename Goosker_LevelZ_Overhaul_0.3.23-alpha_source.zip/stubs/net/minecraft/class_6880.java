package net.minecraft;
public class class_6880<T> {}
