package net.minecraft;
public class class_310 {
    public class_437 field_1755;
    public class_746 field_1724;
    public class_327 field_1772;
    public static class_310 method_1551() { return null; }
    public void method_1507(class_437 screen) {}
    public class_1144 method_1483() { return null; }
}
